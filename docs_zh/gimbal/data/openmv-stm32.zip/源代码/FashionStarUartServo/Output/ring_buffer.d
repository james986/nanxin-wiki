..\output\ring_buffer.o: ..\User\ring_buffer\ring_buffer.c
..\output\ring_buffer.o: ..\User\ring_buffer\ring_buffer.h
..\output\ring_buffer.o: ..\Libraries\CMSIS\stm32f10x.h
..\output\ring_buffer.o: ..\Libraries\CMSIS\core_cm3.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\ARMCC\Bin\..\include\stdint.h
..\output\ring_buffer.o: ..\Libraries\CMSIS\system_stm32f10x.h
..\output\ring_buffer.o: ..\User\stm32f10x_conf.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_adc.h
..\output\ring_buffer.o: ..\Libraries\CMSIS\stm32f10x.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_bkp.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_can.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_cec.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_crc.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_dac.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_dbgmcu.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_dma.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_exti.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_flash.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_fsmc.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_gpio.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_i2c.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_iwdg.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_pwr.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_rcc.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_rtc.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_sdio.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_spi.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_tim.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_usart.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\stm32f10x_wwdg.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\PACK\Keil\STM32F1xx_DFP\2.3.0\Device\StdPeriph_Driver\inc\misc.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\ARMCC\Bin\..\include\stdio.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\ARMCC\Bin\..\include\string.h
..\output\ring_buffer.o: D:\Program Files\Keil\ARM\ARMCC\Bin\..\include\stdlib.h
